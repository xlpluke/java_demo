package GeometricObject;

interface Colorable {
    void howToColor();
}
