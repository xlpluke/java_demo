package GeometricObject;

public class Square extends GeometricObject implements Colorable{
    private double side;

    public double getSide() {
        return side;
    }
    public void setSide(double side) {
        this.side = side;
    }

    public Square(){
        super();
        this.side = 0;
    }
    public Square(double side,String color,boolean filled){
        super(color, filled);
        this.side=side;
    }

    @Override
    public double getArea() {
        return side * side;
    }

    @Override
    public double getPerimeter() {
        return 4 * side;
    }

    @Override
    public void howToColor() {
        System.out.println("Color all four sides.");
    }

    @Override
    public String toString() {
        return "正方形边长: " + side + "\n" + super.toString() + "\n" +
                "面积: " + String.format("%.2f", getArea()) + "\n" +
                "周长: " + String.format("%.2f", getPerimeter());
    }
};
