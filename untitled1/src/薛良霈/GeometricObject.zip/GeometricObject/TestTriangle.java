package GeometricObject;

import java.util.Scanner;

public class TestTriangle {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        System.out.print("输入三角形的三条边");
        double s1 = input.nextDouble();
        double s2 = input.nextDouble();
        double s3 = input.nextDouble();

        System.out.print("请输入颜色");
        String color = input.next();

        System.out.print("是否填充（true/false）：");
        boolean filled = input.nextBoolean();

        Triangle triangle = new Triangle(s1, s2, s3, color, filled);

        System.out.println("\n--- 三角形信息 ---");
        System.out.println("面积: " + String.format("%.2f", triangle.getArea()));
        System.out.println("周长: " + String.format("%.2f", triangle.getPerimeter()));
        System.out.println("颜色: " + triangle.getColor());
        System.out.println("是否填充: " + triangle.isFilled());
        System.out.println("创建时间: " + triangle.getDateCreated());
    }
}