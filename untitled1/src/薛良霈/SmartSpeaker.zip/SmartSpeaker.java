import java.util.Arrays;

interface Playable {
    void play();

    default void pause() {
        System.out.println("暂停播放...");
    }
}

interface Recordable {
    void record();
}

class SmartSpeaker implements Playable, Recordable {
    private int playCount = 0;

    @Override
    public void play() {
        if (playCount >= 3) {
            System.out.println("设备过热，请稍后再试");
        } else {
            playCount++;
            System.out.println("第 " + playCount + " 次播放中...");
        }
    }

    @Override
    public void pause() {
        System.out.println("暂停，当前播放次数：" + playCount);
    }

    @Override
    public void record() {
        System.out.println("开始录音...");
    }
}

interface IntTransformer {
    int transform(int input);
}

class Calculator {
    public static int[] processArray(int[] arr, IntTransformer transformer) {
        int[] result = new int[arr.length];
        for (int i = 0; i < arr.length; i++) {
            result[i] = transformer.transform(arr[i]);
        }
        return result;
    }

    public static void printArray(int[] arr) {
        System.out.println(Arrays.toString(arr));
    }
}

public class Practice {
    public static void main(String[] args) {
        System.out.println("--- 第一题测试 ---");
        SmartSpeaker speaker = new SmartSpeaker();

        for (int i = 0; i < 4; i++) {
            speaker.play();
        }

        speaker.record();
        speaker.pause();

        System.out.println();

        System.out.println("--- 第二题测试 ---");
        int[] numbers = {1, 2, 3, 4, 5};

        IntTransformer timesTwo = input -> input * 2;
        int[] doubled = Calculator.processArray(numbers, timesTwo);
        System.out.print("乘以2结果: ");
        Calculator.printArray(doubled);

        IntTransformer plusTen = input -> input + 10;
        int[] finalResult = Calculator.processArray(doubled, plusTen);
        System.out.print("加10后最终结果: ");
        Calculator.printArray(finalResult);
    }
}