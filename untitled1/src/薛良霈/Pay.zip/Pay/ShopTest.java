package Pay;

public class ShopTest {
    public static void main(String[] args) {
        Priceable[] items = {
                new Book("Java编程思想", 89.0),
                new Toy("变形金刚模型", 45.0),
                new Book("算法导论", 120.0)
        };

        ShoppingCart cart = new ShoppingCart(items);

        System.out.println("=== 购物车商品列表 ===");
        // TODO: 调用 cart.printAllItems()

        System.out.println("\n=== 结算 ===");

        // TODO: 定义无折扣策略 Lambda，命名 noDiscount，调用 calculateTotal 并打印

        // TODO: 定义九折策略 Lambda，命名 ninetyPercent，调用 calculateTotal 并打印

        // TODO: 定义"满100减20"策略 Lambda，命名 fullReduction
        // 提示：这里 Lambda 参数是单件商品的原价，但满减需要判断"总价"，
        //       想一想：能不能直接在 calculateTotal 遍历时用这个策略？
        //       还是应该分两步：先算出普通总价，再判断是否满减？
        //       （这是这道题的思考重点，没有唯一标准答案，写出你的实现思路即可）
    }
}